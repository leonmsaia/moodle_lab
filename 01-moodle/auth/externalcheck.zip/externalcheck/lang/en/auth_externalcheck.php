<?php

$string["pluginname"] = "externalcheck";