<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2025071401;        // YYYYMMDDXX
$plugin->requires  = 2017051504;        // Requiere Moodle 4.0 o superior
$plugin->component = 'auth_externalcheck';